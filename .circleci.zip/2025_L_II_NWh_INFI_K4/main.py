from hello_world import app

if __name__ == "__main__":
    app.run()